﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Second_hand_book_trading_platform
{
    /// <summary>
    /// 存储静态全局变量的类
    /// </summary>
    class common
    {
        public static string strcon = @"Data Source=DESKTOP-UPH7LHR;Initial Catalog=SECOND_BOOK;Integrated Security=True";
        public static string Username = "";
        public static int Admin = 0;
        
    }
}
