use SECOND_BOOK;

--select * from TUser where 

insert into TUser (Username,Password,Tel,Admin) values ('xuziling1','123456','15835716716','0');
insert into TUser (Username,Password,Tel,Admin) values ('xuziling2','123456','15835716716','0');
insert into TUser (Username,Password,Tel,Admin) values ('xuziling3','123456','15835716716','0');
--select * from TUser where Username = 'xuziling' and Password = '123456'; 
--select count(*) from TUser where Username = 'xuziling' and Password = '123456'; 
--select Admin from TUser where Username = 'xuziling';
--insert into TOnline (Username,Admin) values ('xuziling','1');
--DELETE FROM TOnline
--select * from TOnline;
--select * from TBook;
--update [TUser] set [Admin] = '1' where Username = '��hͮ';
--delete from Tuser where  Username = 'wyt';
select * from TUser ;